MIT SOFTWARE LICENSE ---------------------------------------------------------------------------------------------------------------
Copyright 2018 Fil Sapia

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files
(the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

ADDITIONAL LICENSES ---------------------------------------------------------------------------------------------------------------

Graphics card icons are based on styles provided by Chad Remsing - https://thenounproject.com/remsing/

AUTHOR NOTES ----------------------------------------------------------------------------------------------------------------------

Please be aware that in some rare cases disabling/enabling the NVidia GPU may cause a blue screen. Personally, I've only
experienced this once and was not able to reproduce it. I suspect this can happen when the NVidia Optimus switching engine tries to
toggle the state of the dedicated graphics chip at the same time as disabling the adapter from the system using this tool.

This tool has been tested on an NVidia Optimus enabled system running Windows 10 build 1709; again there is no guarantee this
software will function on different hardware to what is was built.